const api = globalThis.browser ?? globalThis.chrome;

const BOTBOUND_ORIGIN = "https://botbound.app";
const STUDIO_HANDOFF_URL = `${BOTBOUND_ORIGIN}/studio/handoff`;
const ROUTES = new Map([
  ["studio", `${BOTBOUND_ORIGIN}/studio`],
  ["agents", `${BOTBOUND_ORIGIN}/overview`],
  ["training", `${BOTBOUND_ORIGIN}/knowledge`],
  ["wire", `${BOTBOUND_ORIGIN}/connections`],
  ["phone", `${BOTBOUND_ORIGIN}/phone`],
  ["inbox", `${BOTBOUND_ORIGIN}/inbox`],
  ["approvals", `${BOTBOUND_ORIGIN}/approvals`],
  ["insights", `${BOTBOUND_ORIGIN}/insights`],
  ["billing", `${BOTBOUND_ORIGIN}/settings/billing`],
]);
const MAX_SELECTION_LENGTH = 1600;
const MAX_DESCRIPTION_LENGTH = 320;

function truncate(value, length) {
  const normalized = typeof value === "string" ? value.trim() : "";
  return normalized.length > length ? `${normalized.slice(0, length - 1)}…` : normalized;
}

function encodeBase64Url(value) {
  const bytes = new TextEncoder().encode(JSON.stringify(value));
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

async function activeTab() {
  const [tab] = await api.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error("No active browser tab is available.");
  return tab;
}

function safeCaptureUrl(raw) {
  if (typeof raw !== "string" || !raw.trim()) return "";
  try {
    const url = new URL(raw);
    return `${url.origin}${url.pathname}`;
  } catch {
    return "";
  }
}

async function capturePageContext(tab, suppliedSelection = "", suppliedLink = "") {
  let pageDetails = { selection: "", description: "" };

  try {
    const result = await api.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        selection: window.getSelection?.().toString() || "",
        description:
          document.querySelector('meta[name="description"]')?.getAttribute("content") || "",
      }),
    });
    pageDetails = result?.[0]?.result || pageDetails;
  } catch {
    // Browser-internal pages and restricted documents cannot be inspected. The tab title and URL remain useful.
  }

  return {
    version: 1,
    source: "browser-extension",
    capturedAt: new Date().toISOString(),
    title: truncate(tab.title || "Untitled page", 180),
    url: safeCaptureUrl(tab.url),
    description: truncate(pageDetails.description, MAX_DESCRIPTION_LENGTH),
    selection: truncate(suppliedSelection || pageDetails.selection, MAX_SELECTION_LENGTH),
    link: typeof suppliedLink === "string" ? suppliedLink : "",
  };
}

function openStudio(context, request = "") {
  const fragment = encodeBase64Url({ ...context, request: truncate(request, 800) });
  return api.tabs.create({ url: `${STUDIO_HANDOFF_URL}#browser-context=${fragment}` });
}

function requestForAction(action, context = {}) {
  const link = typeof context.link === "string" ? context.link.replace(/^tel:/iu, "").trim() : "";
  if (action === "call") {
    return link
      ? `Have a BotBound Bot prepare a personal call to ${link}. Use this page as context, then ask me to confirm before any live call.`
      : "Have a BotBound Bot prepare a personal call using this page as context. Ask me for the number and confirmation before any live call.";
  }
  if (action === "text") {
    return "Have a BotBound Bot draft a text message using this page as context. Ask me to review before sending.";
  }
  if (action === "followup") {
    return "Have a BotBound Bot draft a concise email from this page and selected text. Include the next step, owner, and timing. Ask me to review before sending.";
  }
  return "Use this page and selected text as context for a BotBound Bot task.";
}

async function openCompanion(tab) {
  if (api.sidePanel?.open && tab?.windowId != null) {
    await api.sidePanel.open({ windowId: tab.windowId });
    return;
  }
  if (api.sidebarAction?.open) {
    await api.sidebarAction.open();
    return;
  }
  await api.tabs.create({ url: `${BOTBOUND_ORIGIN}/studio` });
}

async function registerMenus() {
  await api.contextMenus.removeAll();
  api.contextMenus.create({
    id: "wireline-agent-task",
    title: "Ask BotBound about this page",
    contexts: ["page"],
  });
  api.contextMenus.create({
    id: "wireline-capture-selection",
    title: "Send selection to BotBound",
    contexts: ["selection"],
  });
  api.contextMenus.create({
    id: "wireline-call-from-page",
    title: "Prepare a personal call with BotBound",
    contexts: ["page", "selection"],
  });
  api.contextMenus.create({
    id: "wireline-followup-from-page",
    title: "Draft an email with BotBound",
    contexts: ["page", "selection"],
  });
  api.contextMenus.create({
    id: "wireline-call-number",
    title: "Prepare a personal call to this number",
    contexts: ["link"],
    targetUrlPatterns: ["tel:*"],
  });
}

api.runtime.onInstalled.addListener(() => {
  void registerMenus();
  void api.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true });
});

api.action?.onClicked.addListener((tab) => {
  void openCompanion(tab).catch(() => undefined);
});

api.commands.onCommand.addListener((command) => {
  if (command !== "capture-current-page") return;
  void activeTab()
    .then((tab) => capturePageContext(tab))
    .then((context) => openStudio(context, requestForAction("task", context)))
    .catch(() => undefined);
});

api.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab?.id) return;
  void capturePageContext(tab, info.selectionText || "", info.linkUrl || "")
    .then((context) => {
      const action =
        info.menuItemId === "wireline-call-number" || info.menuItemId === "wireline-call-from-page"
          ? "call"
          : info.menuItemId === "wireline-text-from-page"
            ? "text"
            : info.menuItemId === "wireline-followup-from-page"
              ? "followup"
              : "task";
      return openStudio(context, requestForAction(action, context));
    })
    .catch(() => undefined);
});

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const run = async () => {
    if (message?.type === "wireline:get-active-context") {
      const tab = await activeTab();
      return capturePageContext(tab);
    }
    if (message?.type === "wireline:open-studio") {
      const tab = await activeTab();
      const context = await capturePageContext(tab, message.selection || "");
      await openStudio(context, message.request || requestForAction(message.action || "task", context));
      return { opened: true };
    }
    if (message?.type === "wireline:open-route") {
      const url = ROUTES.get(message.route || "studio");
      if (!url) throw new Error("Unsupported BotBound route.");
      await api.tabs.create({ url });
      return { opened: true };
    }
    throw new Error("Unsupported BotBound Command request.");
  };

  void run().then(
    (result) => sendResponse({ ok: true, result }),
    (error) => sendResponse({ ok: false, error: error instanceof Error ? error.message : "Unable to complete request." }),
  );
  return true;
});
